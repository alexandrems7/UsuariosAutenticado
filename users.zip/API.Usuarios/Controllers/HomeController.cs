﻿using API.Usuarios.Data.Repositories;
using API.Usuarios.Models;
using API.Usuarios.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Usuarios.Controllers
{
    public class HomeController
    {
        [Route("api/login")]
        public async Task<ActionResult<dynamic>> AuthenticateAsync([FromBody] Usuario usuario)
        {


            //recupera o usuário
            var user = UsuariosRepository.Buscar();

            //verifica se o usuário existe
            if (usuario.Email == null && usuario.Senha == null)
            {
                return NotFound(message = "usuario nao encotnrado");
            }


            // gera o token
            var token = await TokenService.GenerateToken(user);

            // oculta a senha
            usuario.Senha = "";

            // retorna os dados
            return new
            {
                user = usuario.Email,
                token = token
            };
        }

    }
}
