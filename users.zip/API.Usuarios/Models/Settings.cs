﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Usuarios.Models
{
    public static class Settings
    {
        public static string secret = "meusegredosecreto";
    }
}
